﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace newproject
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            String text = maskedTextBox1.Text;
            
            String texts = maskedTextBox2.Text;
            if (text == "rakshi imalka" && texts=="rakima")
            {
                MessageBox.Show(text + "it is correct" + texts + "IS correct");
            }
            else
            {
                MessageBox.Show(text+"it is not correct "+texts+" also can not correct");
            }
            
        }
    }
}
